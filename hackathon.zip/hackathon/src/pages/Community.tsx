import React, { useState } from "react";
import { ArrowLeft, MessageCircle, ThumbsUp, Send } from "lucide-react";
import { Link } from "react-router-dom";

interface Post {
  id: number;
  user: string;
  content: string;
  comments: string[];
  likes: number;
}

export default function Community() {
  const [posts, setPosts] = useState<Post[]>([
    {
      id: 1,
      user: "Rahul Mehta",
      content:
        "🚀 Looking for a CTO to join my AI-powered EdTech startup. If you're passionate about AI & Education, let's connect!",
      comments: ["I’m interested! Let’s talk.", "What’s your tech stack?"],
      likes: 12,
    },
    {
      id: 2,
      user: "Neha Sharma",
      content:
        "🔥 My biggest startup challenge is finding early adopters. Any tips on how to acquire first 100 customers?",
      comments: [
        "Try reaching out on LinkedIn!",
        "Build in public and share your journey!",
      ],
      likes: 18,
    },
    {
      id: 3,
      user: "Aditya Verma",
      content:
        "💡 Bootstrapping vs VC Funding? I’m torn between scaling quickly or keeping control of my startup. What do you all think?",
      comments: ["Depends on your goals!", "Try angel investors first!"],
      likes: 9,
    },
  ]);

  const handleLike = (postId: number) => {
    setPosts(
      posts.map((post) =>
        post.id === postId ? { ...post, likes: post.likes + 1 } : post
      )
    );
  };

  const handleComment = (postId: number, comment: string) => {
    if (!comment.trim()) return;
    setPosts(
      posts.map((post) =>
        post.id === postId
          ? { ...post, comments: [...post.comments, comment] }
          : post
      )
    );
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-[#F8F9FA] to-[#E9ECEF] p-6">
      {/* Header Section */}
      <div className="w-full max-w-5xl bg-white rounded-xl shadow-lg p-8 border border-gray-200">
        {/* Back Button */}
        <Link
          to="/"
          className="flex items-center text-[#005F73] hover:underline mb-4"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Home
        </Link>

        {/* Title */}
        <h1 className="text-4xl font-extrabold text-center text-[#005F73] mb-4">
          🌍 Community Hub
        </h1>
        <p className="text-center text-gray-600">
          Collaborate, find co-founders, and share startup challenges.
        </p>
      </div>

      {/* Posts Section */}
      <div className="w-full max-w-4xl mt-8 space-y-6">
        {posts.map((post) => (
          <div
            key={post.id}
            className="bg-white rounded-lg shadow-md p-6 border border-gray-200"
          >
            <h2 className="text-xl font-semibold text-[#343A40]">
              {post.user}
            </h2>
            <p className="text-gray-600 mt-2">{post.content}</p>

            {/* Like & Comment Buttons */}
            <div className="flex items-center mt-4 space-x-4">
              <button
                onClick={() => handleLike(post.id)}
                className="flex items-center text-gray-600 hover:text-[#005F73] transition"
              >
                <ThumbsUp className="h-5 w-5 mr-1" /> {post.likes}
              </button>
              <button className="flex items-center text-gray-600 hover:text-[#005F73] transition">
                <MessageCircle className="h-5 w-5 mr-1" />{" "}
                {post.comments.length}
              </button>
            </div>

            {/* Comments Section */}
            <div className="mt-4">
              {post.comments.map((comment, index) => (
                <p key={index} className="text-gray-500 text-sm mt-1">
                  💬 {comment}
                </p>
              ))}

              {/* Add Comment Input */}
              <div className="mt-4 flex items-center space-x-2">
                <input
                  type="text"
                  placeholder="Add a comment..."
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#005F73]"
                  onKeyDown={(e) => {
                    if (e.key === "Enter")
                      handleComment(
                        post.id,
                        (e.target as HTMLInputElement).value
                      );
                  }}
                />
                <button
                  onClick={() => handleComment(post.id, "Great point!")}
                  className="px-4 py-2 bg-[#005F73] text-white rounded-lg hover:bg-[#004F63]"
                >
                  <Send className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
