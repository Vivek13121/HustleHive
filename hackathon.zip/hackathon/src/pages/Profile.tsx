import React from "react";
import { ArrowLeft, Linkedin } from "lucide-react";
import { Link } from "react-router-dom";

export default function Profile() {
  // Mocked LinkedIn Profile Data
  const profile = {
    name: "Vivek",
    pronouns: "He/Him",
    title: "PEC CSE'28 | Python | Web Dev",
    organization: "PEC ACM CSS",
    location: "Chandigarh, India",
    education: [
      {
        institution: "Punjab Engineering College",
        degree: "BTech, Computer Science and Engineering",
        years: "2024 - 2028",
        grade: "9.95 CGPA",
      },
      {
        institution: "Bharatiya Vidya Bhavan, Chandigarh",
        degree: "12th, Non-medical",
        years: "2022 - 2024",
        grade: "95.6%",
      },
    ],
    linkedinURL: "https://www.linkedin.com/in/vivek-%E2%80%8E-40a9a3310/", // Replace with your real profile
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#F8F9FA] to-[#E9E9E9] p-6">
      <div className="w-full max-w-lg bg-white rounded-lg shadow-lg p-6">
        {/* Back Button */}
        <Link
          to="/"
          className="flex items-center text-[#005F73] hover:opacity-80 mb-4"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Home
        </Link>

        {/* Profile Info */}
        <div className="text-center">
          <img
            src={`https://ui-avatars.com/api/?name=${profile.name}&background=005F73&color=fff&size=128`}
            alt="Profile Avatar"
            className="w-24 h-24 rounded-full mx-auto shadow-md"
          />
          <h2 className="text-2xl font-semibold text-[#005F73] mt-3">
            {profile.name} ({profile.pronouns})
          </h2>
          <p className="text-gray-600">{profile.title}</p>
          <p className="text-gray-500">{profile.organization}</p>
          <p className="text-gray-500">📍 {profile.location}</p>

          {/* LinkedIn Button */}
          <a
            href={profile.linkedinURL}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-4 inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
          >
            <Linkedin className="h-5 w-5 mr-2" />
            View LinkedIn
          </a>
        </div>

        {/* Education Section */}
        <div className="mt-6">
          <h3 className="text-lg font-semibold text-[#005F73]">Education</h3>
          {profile.education.map((edu, index) => (
            <div key={index} className="mt-2 border-l-4 pl-3 border-blue-500">
              <p className="font-medium">{edu.institution}</p>
              <p className="text-sm text-gray-600">
                {edu.degree} ({edu.years})
              </p>
              <p className="text-sm text-gray-500">Grade: {edu.grade}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
