import { useEffect, useState } from "react";
import { ArrowLeft, UserCheck } from "lucide-react";
import { Link } from "react-router-dom";

interface Founder {
  name: string;
  title: string;
  company: string;
  expertise: string[];
}

const mockFounders: Founder[] = [
  {
    name: "Rahul Sharma",
    title: "CEO & Founder",
    company: "TechVista",
    expertise: ["AI", "Product Management", "Scaling Startups"],
  },
  {
    name: "Ananya Gupta",
    title: "CTO",
    company: "NextGen Solutions",
    expertise: ["Web Development", "Cloud Computing", "Security"],
  },
  {
    name: "Amit Verma",
    title: "Startup Mentor",
    company: "IndieGrowth",
    expertise: ["Marketing", "Fundraising", "Networking"],
  },
];

export default function FounderMatching() {
  const [matchedFounder, setMatchedFounder] = useState<Founder | null>(null);

  useEffect(() => {
    // Simulate a match based on profile needs (Mock Logic)
    const randomIndex = Math.floor(Math.random() * mockFounders.length);
    setMatchedFounder(mockFounders[randomIndex]);
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-gray-100 to-gray-300 p-6">
      <div className="bg-white shadow-xl rounded-lg p-8 w-full max-w-md text-center">
        <Link
          to="/"
          className="flex items-center text-gray-600 hover:text-gray-900 mb-4"
        >
          <ArrowLeft className="h-5 w-5 mr-2" /> Back to Home
        </Link>
        <h2 className="text-2xl font-bold text-gray-800 mb-4">
          Founder Match Found!
        </h2>
        {matchedFounder ? (
          <div className="p-4 border rounded-lg shadow-md bg-gray-50">
            <UserCheck className="h-10 w-10 text-green-500 mx-auto mb-3" />
            <h3 className="text-xl font-semibold">{matchedFounder.name}</h3>
            <p className="text-gray-700">
              {matchedFounder.title} at {matchedFounder.company}
            </p>
            <h4 className="mt-3 font-semibold text-gray-800">Expertise:</h4>
            <ul className="text-gray-600">
              {matchedFounder.expertise.map((skill, index) => (
                <li key={index}>• {skill}</li>
              ))}
            </ul>
            <button className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
              Connect Now
            </button>
          </div>
        ) : (
          <p className="text-gray-600">Finding your perfect match...</p>
        )}
      </div>
    </div>
  );
}
