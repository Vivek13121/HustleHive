import React, { useEffect, useState } from "react";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

interface Article {
  title: string;
  description: string;
  url: string;
  source: string;
}

const KnowledgeHub: React.FC = () => {
  const [articles, setArticles] = useState<Article[]>([]);

  useEffect(() => {
    // Mock data representing fetched articles
    const fetchedArticles: Article[] = [
      {
        title: "Auxia Secures $23.5M to Revolutionize AI Marketing",
        description:
          "Auxia, an AI marketing startup, has raised $23.5 million to enhance personalized consumer shopping experiences using AI agents.",
        url: "https://www.businessinsider.com/pitch-deck-ai-marketing-agent-startup-auxia-raise-vc-funding-2025-3",
        source: "Business Insider",
      },
      {
        title: "SoftBank Acquires Ampere Computing for $6.5 Billion",
        description:
          "SoftBank deepens its AI investments by acquiring chipmaker Ampere Computing, aiming to bolster AI infrastructure.",
        url: "https://www.reuters.com/markets/deals/softbank-group-acquire-ampere-computing-65-billion-deal-2025-03-19/",
        source: "Reuters",
      },
      {
        title: "Healthtech VCs Turn to AI for Next Wave of Returns",
        description:
          "Venture capitalists are leveraging AI to rejuvenate the healthtech industry, aiming for improved healthcare efficiency.",
        url: "https://www.wsj.com/articles/healthtech-vcs-look-to-ai-for-next-wave-of-returns-5ff167fd",
        source: "The Wall Street Journal",
      },
    ];

    setArticles(fetchedArticles);
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-[#F8F9FA] to-[#E9ECEF] p-6">
      {/* Header Section */}
      <div className="w-full max-w-5xl bg-white backdrop-blur-md rounded-xl shadow-lg p-8 border border-gray-200">
        {/* Back Button */}
        <Link
          to="/"
          className="flex items-center text-[#005F73] hover:underline mb-4"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Home
        </Link>

        {/* Title */}
        <h1 className="text-4xl font-extrabold text-center text-[#005F73] mb-4">
          🚀 Knowledge Hub
        </h1>
        <p className="text-center text-gray-600">
          Stay updated with the latest news on startups & technology.
        </p>
      </div>

      {/* News Cards Container */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mt-8 w-full max-w-6xl">
        {articles.map((article, index) => (
          <a
            key={index}
            href={article.url}
            target="_blank"
            rel="noopener noreferrer"
            className="relative bg-white rounded-xl shadow-lg p-6 transition-all hover:scale-105 hover:shadow-2xl border border-gray-200"
          >
            <h2 className="text-2xl font-semibold text-[#343A40]">
              {article.title}
            </h2>
            <p className="text-gray-600 mt-2">{article.description}</p>
            <p className="text-sm text-gray-500 mt-2">
              Source: {article.source}
            </p>

            {/* Fancy Border Effect */}
            <div className="absolute inset-0 rounded-xl border-2 border-transparent group-hover:border-[#005F73] transition-all"></div>
          </a>
        ))}
      </div>
    </div>
  );
};

export default KnowledgeHub;
