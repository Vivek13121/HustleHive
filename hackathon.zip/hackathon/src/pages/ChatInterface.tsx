import * as React from "react";
import { useState, useRef, useEffect } from "react";
import { Send, ArrowLeft } from "lucide-react";

interface Message {
  id: string;
  type: "user" | "ai";
  content: string;
  timestamp: Date;
}

const mockResponses: { [key: string]: string } = {
  "What is an MVP?":
    "An MVP (Minimum Viable Product) is the simplest version of a product that allows a team to collect maximum validated learning about customers with minimal effort.",
  "How do I get startup funding?":
    "Startup funding can come from various sources, such as bootstrapping, angel investors, venture capitalists, or crowdfunding.",
  "What are some key metrics for startups?":
    "Key metrics include Customer Acquisition Cost (CAC), Lifetime Value (LTV), Monthly Recurring Revenue (MRR), and Churn Rate.",
  "How do I scale my startup?":
    "Scaling a startup involves optimizing product-market fit, automating processes, and expanding marketing channels while ensuring operational efficiency.",
  "What are the best ways to attract investors to my startup?":
    "To attract investors, you need to demonstrate strong traction, a scalable business model, and a clear competitive advantage. Start by preparing a compelling pitch deck that highlights your market opportunity, team strengths, financial projections, and how the investment will drive growth. Networking plays a huge role—attend pitch events, connect with investors in your industry, and leverage warm introductions through mutual contacts. Also, consider alternative funding options like crowdfunding, grants, or revenue-based financing if equity investment isn't the best fit. Would you like help refining your pitch deck or finding potential investors?",
};

export default function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const generateAIResponse = async (userInput: string) => {
    return (
      mockResponses[userInput] ||
      "That's an interesting question! Currently, I can answer common startup-related queries."
    );
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      content: inputValue,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");
    setIsTyping(true);

    setTimeout(async () => {
      const aiResponse = await generateAIResponse(inputValue);
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: "ai",
        content: aiResponse,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, aiMessage]);
      setIsTyping(false);
    }, 1000);
  };

  return (
    <div className="flex flex-col h-screen bg-[#F8F9FA]">
      <div className="bg-white border-b border-gray-200 px-6 py-4 flex items-center">
        <a
          href="/"
          className="flex items-center text-[#005F73] hover:opacity-80 transition-opacity"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          <span>Back to Home</span>
        </a>
        <h1 className="text-2xl font-bold text-[#005F73] ml-6">
          AI Startup Coach
        </h1>
      </div>
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {messages.length === 0 ? (
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold text-[#005F73] mb-4">
              Welcome to Your AI Startup Coach! 👋
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              I'm here to help you with startup advice, business strategies, and
              entrepreneurial guidance. What would you like to know about?
            </p>
          </div>
        ) : (
          messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${
                message.type === "user" ? "justify-end" : "justify-start"
              }`}
            >
              <div
                className={`max-w-[70%] p-4 rounded-2xl shadow-sm ${
                  message.type === "user"
                    ? "bg-[#005F73] text-white rounded-br-none"
                    : "bg-white text-gray-800 rounded-bl-none"
                }`}
              >
                <p className="text-sm whitespace-pre-wrap">{message.content}</p>
              </div>
            </div>
          ))
        )}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-white p-4 rounded-2xl rounded-bl-none shadow-sm">
              <div className="flex space-x-2">
                <div className="w-2 h-2 bg-[#005F73] rounded-full animate-bounce" />
                <div
                  className="w-2 h-2 bg-[#005F73] rounded-full animate-bounce"
                  style={{ animationDelay: "0.2s" }}
                />
                <div
                  className="w-2 h-2 bg-[#005F73] rounded-full animate-bounce"
                  style={{ animationDelay: "0.4s" }}
                />
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      <form
        onSubmit={handleSendMessage}
        className="border-t border-gray-200 bg-white p-6"
      >
        <div className="max-w-4xl mx-auto flex space-x-4">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder={
              messages.length === 0
                ? "Ask about startup funding, MVP, scaling..."
                : "Type your question..."
            }
            className="flex-1 px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#005F73] focus:border-transparent"
          />
          <button
            type="submit"
            disabled={!inputValue.trim() || isTyping}
            className="px-6 py-3 bg-[#005F73] text-white rounded-xl font-medium hover:bg-[#004F63] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
          >
            <Send className="h-5 w-5" />
          </button>
        </div>
      </form>
    </div>
  );
}
