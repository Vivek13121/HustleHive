import { useState } from "react";
import { Linkedin } from "lucide-react";

export default function LinkedInAuth() {
  const [linkedInID, setLinkedInID] = useState("");
  interface Profile {
    name: string;
    pronouns: string;
    title: string;
    organization: string;
    location: string;
    education: {
      institution: string;
      degree: string;
      years: string;
      grade: string;
    }[];
  }

  const [profile, setProfile] = useState<Profile | null>(null);

  const handleJoin = () => {
    if (!linkedInID.trim()) return;

    // Mocked profile data extraction
    const mockProfile = {
      name: "Vivek",
      pronouns: "He/Him",
      title: "PEC CSE'28 | Python | Web Dev",
      organization: "PEC ACM CSS",
      location: "Chandigarh, India",
      education: [
        {
          institution: "Punjab Engineering College",
          degree: "BTech, Computer Science and Engineering",
          years: "2024 - 2028",
          grade: "9.95 CGPA",
        },
        {
          institution: "Bharatiya Vidya Bhavan, Chandigarh",
          degree: "12th, Non-medical",
          years: "2022 - 2024",
          grade: "95.6%",
        },
      ],
    };

    setProfile(mockProfile);
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-md w-96 mx-auto">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">
        Join via LinkedIn
      </h2>
      {!profile ? (
        <>
          <input
            type="text"
            placeholder="Enter LinkedIn ID or URL"
            value={linkedInID}
            onChange={(e) => setLinkedInID(e.target.value)}
            className="w-full px-3 py-2 border rounded-md mb-4"
          />
          <button
            onClick={handleJoin}
            className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center justify-center hover:bg-blue-700"
          >
            <Linkedin className="mr-2 h-5 w-5" /> Join via LinkedIn
          </button>
        </>
      ) : (
        <div>
          <h3 className="text-lg font-semibold">
            {profile.name} ({profile.pronouns})
          </h3>
          <p className="text-gray-600">{profile.title}</p>
          <p className="text-gray-500">{profile.organization}</p>
          <p className="text-gray-500">📍 {profile.location}</p>
          <h4 className="font-semibold mt-4">Education</h4>
          {profile.education.map((edu, index) => (
            <div key={index} className="mt-2 border-l-4 pl-2 border-blue-500">
              <p className="font-medium">{edu.institution}</p>
              <p className="text-sm text-gray-600">
                {edu.degree} ({edu.years})
              </p>
              <p className="text-sm text-gray-500">Grade: {edu.grade}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
