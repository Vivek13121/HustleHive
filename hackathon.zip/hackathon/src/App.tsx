import { useEffect, useRef } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import {
  Globe2,
  ArrowRight,
  Linkedin,
  Handshake,
  Tags,
  UserCheck,
  Megaphone,
  Brain,
  MessageSquare,
  Search,
  Home,
  Users,
  Bell,
  Bot,
  MessageCircle,
  User,
} from "lucide-react";
import ChatInterface from "./pages/ChatInterface";
import LinkedInAuth from "./components/LinkedInAuth";
import FounderMatching from "./pages/FounderMatching";
import Profile from "./pages/Profile";
import KnowledgeHub from "./pages/KnowledgeHub";
import Community from "./pages/Community";

function NetworkBackground() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Create network nodes
    const nodes = Array.from({ length: 15 }, (_, i) => {
      const node = document.createElement("div");
      node.className = "network-node";
      node.style.left = `${Math.random() * 100}%`;
      node.style.top = `${Math.random() * 100}%`;
      node.style.animation = `float-${(i % 3) + 1} ${
        6 + Math.random() * 4
      }s ease-in-out infinite`;
      node.style.transform = `translate3d(0, 0, ${Math.random() * 50}px)`;
      return node;
    });

    // Create connecting lines
    const lines = Array.from({ length: 10 }, () => {
      const line = document.createElement("div");
      line.className = "network-line";
      line.style.width = `${100 + Math.random() * 150}px`;
      line.style.left = `${Math.random() * 100}%`;
      line.style.top = `${Math.random() * 100}%`;
      line.style.transform = `rotate(${
        Math.random() * 360
      }deg) translate3d(0, 0, ${Math.random() * 30}px)`;
      line.style.animation = `float-${Math.floor(Math.random() * 3) + 1} ${
        8 + Math.random() * 4
      }s ease-in-out infinite`;
      return line;
    });

    // Add elements to container
    nodes.forEach((node) => containerRef.current?.appendChild(node));
    lines.forEach((line) => containerRef.current?.appendChild(line));

    // Cleanup
    return () => {
      nodes.forEach((node) => node.remove());
      lines.forEach((line) => line.remove());
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className="absolute inset-0 overflow-hidden pointer-events-none"
      style={{ perspective: "1000px" }}
    />
  );
}

function Navbar() {
  return (
    <nav className="fixed top-0 w-full bg-white/80 backdrop-blur-lg border-b border-gray-200 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <Globe2 className="h-8 w-8 text-[#005F73]" />
              <span className="ml-2 text-xl font-bold text-[#005F73]">
                HustleHive
              </span>
            </Link>
          </div>
          <div className="hidden md:flex items-center space-x-8">
            {[
              { icon: Home, text: "Home", path: "/" },
              { icon: Users, text: "Founder Matching", path: "/matching" },

              { icon: Bell, text: "Knowledge Hub", path: "/knowledge-hub" },
              { icon: Bot, text: "AI Chatbot", path: "/chat" },
              { icon: MessageCircle, text: "Community", path: "/community" },
              { icon: User, text: "Profile", path: "/profile" },
            ].map((item, index) => (
              <Link
                key={index}
                to={item.path}
                className="flex items-center text-[#343A40] hover:text-[#005F73] transition-colors"
              >
                <item.icon className="h-4 w-4 mr-1" />
                <span>{item.text}</span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
}

function Hero() {
  return (
    <div className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-[#F8F9FA] to-[#E9E9E9] overflow-hidden">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
        <NetworkBackground />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 className="text-5xl md:text-7xl font-bold text-[#005F73] leading-tight mb-6">
          Connecting Founders.
          <br />
          Fueling Innovation.
          <br />
          Empowering Journeys.
        </h1>
        <p className="text-xl md:text-2xl text-[#343A40] mb-12 max-w-3xl mx-auto">
          A global platform where entrepreneurs share, learn, and grow together
          through AI-powered networking and mentorship.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <button className="px-8 py-4 bg-[#EE6C4D] text-white rounded-lg font-semibold flex items-center justify-center hover:bg-[#F4A261] transition-colors">
            Get Started
            <ArrowRight className="ml-2 h-5 w-5" />
          </button>
          <Link to="/linkedin">
            <button className="px-8 py-4 bg-[#005F73] text-white rounded-lg font-semibold flex items-center justify-center hover:opacity-90 transition-opacity">
              <Linkedin className="mr-2 h-5 w-5" />
              Join via LinkedIn
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}

function JourneyStep({ icon: Icon, title, description, isActive = false }) {
  return (
    <div
      className={`relative flex items-center p-6 rounded-xl bg-white shadow-lg transition-all duration-300 ${
        isActive ? "scale-105" : "hover:scale-105"
      }`}
    >
      <div className="mr-4">
        <div className="p-3 rounded-full bg-[#005F73] text-white">
          <Icon className="h-6 w-6" />
        </div>
      </div>
      <div>
        <h3 className="text-xl font-semibold text-[#343A40]">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </div>
    </div>
  );
}

function Journey() {
  const steps = [
    {
      icon: Handshake,
      title: "Onboard & Connect",
      description: "Sign up and get matched with like-minded founders",
    },
    {
      icon: Tags,
      title: "Your Smart Tags",
      description: "AI-powered profile tagging for better connections",
    },
    {
      icon: UserCheck,
      title: "Get Recommendations",
      description: "Discover perfect matches for your startup journey",
    },
    {
      icon: Megaphone,
      title: "Share & Shine",
      description: "Share updates and showcase your progress",
    },
    {
      icon: Brain,
      title: "Your Virtual Coach",
      description: "Get AI-powered insights and guidance",
    },
    {
      icon: MessageSquare,
      title: "Grow Together",
      description: "Engage with the community and learn from peers",
    },
  ];

  return (
    <div className="py-20 bg-[#F8F9FA]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl font-bold text-center text-[#005F73] mb-16">
          Your Founder Journey
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <JourneyStep key={index} {...step} />
          ))}
        </div>
      </div>
    </div>
  );
}

function Features() {
  return (
    <div className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="flex-1">
            <div className="bg-[#F8F9FA] p-6 rounded-xl shadow-lg">
              <div className="flex items-center mb-4">
                <Search className="h-6 w-6 text-[#005F73]" />
                <h3 className="ml-2 text-xl font-semibold">Find Founders</h3>
              </div>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search for founders..."
                  className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#005F73]"
                />
              </div>
            </div>
          </div>

          <div className="flex-1">
            <div className="bg-[#F8F9FA] p-6 rounded-xl shadow-lg">
              <div className="flex items-center mb-4">
                <MessageSquare className="h-6 w-6 text-[#005F73]" />
                <h3 className="ml-2 text-xl font-semibold">Hot Topics</h3>
              </div>
              <div className="space-y-4">
                {[
                  "Startup Funding Tips",
                  "Tech Stack Choices",
                  "Marketing Strategies",
                ].map((topic, index) => (
                  <div key={index} className="p-4 bg-white rounded-lg shadow">
                    <h4 className="font-medium text-[#343A40]">{topic}</h4>
                    <p className="text-sm text-gray-500">
                      12 founders discussing
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function HomePage() {
  return (
    <div className="min-h-screen bg-[#F8F9FA]">
      <Hero />
      <Journey />
      <Features />
    </div>
  );
}

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-[#F8F9FA]">
        <Navbar />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/chat" element={<ChatInterface />} />
          <Route path="/linkedin" element={<LinkedInAuth />} />
          <Route path="/matching" element={<FounderMatching />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/knowledge-hub" element={<KnowledgeHub />} />
          <Route path="/community" element={<Community />} />

          {/* Add other routes as needed */}
        </Routes>
      </div>
    </Router>
  );
}

export default App;
